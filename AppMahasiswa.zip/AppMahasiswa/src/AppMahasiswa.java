/**
 * @(#)AppMahasiswa.java
 *
 * AppMahasiswa application
 *
 * @author 
 * @version 1.00 2017/10/11
 */

import java.util.*;

class Program {
	
	public void showMainMenu() {
		System.out.println(
			"1. Menambahkan data mahasiswa\n" +
			"2. Menghapus data mahasiswa\n" +
			"3. Mengubah data mahasiswa\n" +
			"4. Mengurutkan data mahasiswa\n" +
			"5. Menampilkan data mahasiswa\n"
		);
		
		System.out.print("Pilih Menu: ");
	}
}
 
public class AppMahasiswa {
    
    public static void main(String[] args) {
    	
    	/*
    	
    	AppMahasiswaFrame frame = new AppMahasiswaFrame();
    	frame.setVisible(true);  	
		
		*/
    	
    	Scanner in;
    	Program p;
    	int menu, i;
    	String newMhs, oldMhs;
    	ArrayList<String> mhs;
    	
    	in = new Scanner(System.in);
    	p = new Program();
    	mhs = new ArrayList<>();
    	
    	do{
	    	p.showMainMenu();
	    	menu = Integer.valueOf(in.next());
	    	
	    	switch(menu) {
	    		case 1:
	    			System.out.print("Masukkan nama Mahasiswa: \n");
	    			newMhs = in.next();
	    			mhs.add(newMhs);
	    			System.out.println ("Mahasiswa bernama "+ newMhs +" berhasil ditambahkan");
	    		break;
	    		
	    		case 2:
	    			if (mhs.isEmpty()) {
	    				System.out.println ("Data Mahasiswa kosong.");
	    			} else {
	    				System.out.println(
	    					"2.1. Hapus Berdasarkan Nama\n"+
	    					"2.2. Hapus Berdasarkan Index\n"
	    				);
	    				
	    				System.out.print("Pilih Menu: ");
	    				menu = in.nextInt();
	    				
	    				switch(menu) {
	    					case 1:
	    						System.out.print("Masukkan nama Mahasiswa: ");
	    						oldMhs = in.next();
	    						mhs.remove(oldMhs);
	    						System.out.println ("Mahasiswa bernama "+ oldMhs +" berhasil dihapus");
	    					break;
	    					
	    					case 2:
	    						System.out.print("Masukkan index array: ");
	    						i = in.nextInt();
	    						if (i < 0 && i > mhs.size()-1) {
			    					System.out.println ("Masukkan index dengan benar!");
			    				} else {
			    					mhs.remove(i);
	    							System.out.println ("Mahasiswa pada index ke-"+ i +" berhasil dihapus");
			    				}
	    					break;
				    	}
	    			}
	    		break;
	    		
	    		case 3:
	    			if (mhs.isEmpty()) {
	    				System.out.println ("Data Mahasiswa kosong.");
	    			} else {
	    				System.out.println("Masukkan index array: ");
	    				i = in.nextInt();
	    				if (i < 0 && i > mhs.size()-1) {
	    					System.out.println ("Masukkan index dengan benar!");
	    				} else {	    					
		    				System.out.println("Masukkan nama baru Mahasiswa: ");
		    				newMhs = in.next();
		    				mhs.set(i, newMhs);
		    				System.out.println ("Mahasiswa index ke-"+ i +" berhasil diperbarui");
		    			}
	    			}
	    		break;
	    		
	    		case 4:
	    			if (mhs.size() < 2) {
	    				System.out.println("Data Mahasiswa hanya berisi 1 data.");
	    			} else {
	    				Collections.sort(mhs);
	    			}
	    		break;
	    		
	    		case 5:
	    			System.out.println(mhs);
	    		break;
	    		
	    		default:
	    			System.out.println("Pilihan menu tidak tersedia.");
	    		break;
	    	}
	    	
	    	System.out.print("Kembali ke Menu Utama? [1 = Ya | 0 = Tidak]\n");
	    	System.out.print("Pilihan Anda: ");
	    	menu = Integer.valueOf(in.next());
	    	
		}while(menu == 1);  
    }
}
