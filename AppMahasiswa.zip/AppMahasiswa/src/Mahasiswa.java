/**
 * @(#)Mahasiswa.java
 *
 *
 * @author 
 * @version 1.00 2017/10/11
 */


public class Mahasiswa {

	String nama;

    public Mahasiswa(String nama) {
	    this.nama = nama;	    
    }
    
    public String getNama(int i) {
    	return nama;
    }
    
    
}