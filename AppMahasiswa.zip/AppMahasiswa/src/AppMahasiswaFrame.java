/**
 * @(#)AppMahasiswaFrame.java
 *
 *
 * @author 
 * @version 1.00 2017/10/11
 */

import java.awt.*;
import javax.swing.*;

public class AppMahasiswaFrame extends JFrame {

    public AppMahasiswaFrame() {
    	
    	JOptionPane dialog;
    	String newMhs, oldMhs;
    	int menu, i;
    	
    	dialog = new JOptionPane(); 
    	newMhs = dialog.showInputDialog("Masukkan Nama Mahasiswa");
    
    }
    
}