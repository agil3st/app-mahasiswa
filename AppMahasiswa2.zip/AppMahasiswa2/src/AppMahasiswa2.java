/**
 * @(#)AppMahasiswa2.java
 *
 * AppMahasiswa2 application
 *
 * @author Kingmaster772
 * @version 2.00 2017/10/13
 */

import gui.AppMahasiswaFrame;

public class AppMahasiswa2 {
    
    public static void main(String[] args) {
    	
    	try {
	    	AppMahasiswaFrame frame = new AppMahasiswaFrame();
	    	frame.setVisible(true);
	    } catch(NumberFormatException e) {
	    	System.out.println ("masukkan menu dengan benar.");
	    }
    	
    }
}
