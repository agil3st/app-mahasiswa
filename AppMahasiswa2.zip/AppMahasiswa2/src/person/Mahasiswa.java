package person;

public class Mahasiswa {
	private String nama, npm;	

	public Mahasiswa() {
	}
		
	public Mahasiswa(String nama) {
		this.nama = nama;
	}
	
	public Mahasiswa(String npm, String nama) {
		this.npm = npm;
		this.nama = nama;
	}
	
	public String getNPM() {
		return npm;
	}

	public String getNama() {
		return nama;
	}	
}
