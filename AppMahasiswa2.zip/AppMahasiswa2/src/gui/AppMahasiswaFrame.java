/**
 * @(#)AppMahasiswaFrame.java
 *
 *
 * @author 
 * @version 1.00 2017/10/11
 */

package gui;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import person.Mahasiswa;

public class AppMahasiswaFrame extends JFrame {
    	
	private JOptionPane dialog;
	private String npm, nama, msg, val;
	private int menu, i;
	private Mahasiswa newMhs, oldMhs;
	private ArrayList<Mahasiswa> mhs; 

    public AppMahasiswaFrame() {
		mhs = new ArrayList<Mahasiswa>();
    	showMainMenu();
    }
    
    private void showMainMenu() {
    	dialog = new JOptionPane();
    	menu = Integer.parseInt(dialog.showInputDialog(
    		"Jumlah Mahasiswa: "+ mhs.size() +"\n\n"+
    		"1. Tambah Mahasiswa\n"+
    		"2. Perbarui Mahasiswa\n"+
    		"3. Hapus Mahasiswa\n"+
    		"4. Urutkan Data\n"+
    		"5. Tampilkan Data\n"+
    		"6. Exit\n\n"+
    		"Pilih Menu:"));
    	
    	showMenu(menu);
    	showMainMenu();
    }
    
    private void showMenu(int menu) {
    	dialog = new JOptionPane();
    	
    	switch(menu) {
    		case 1:
    			addMhs();
    		break;
    		
    		case 2:
    			//dialog.showMessageDialog(null, "Menu 3");
    			
    			if (mhs.size()<1) {
    				dialog.showMessageDialog(null, "Data Mahasiswa masih kosong.");
    			} else {
	    			i = Integer.parseInt(dialog.showInputDialog("Masukkan index array:"));
	    			editMhs(i-1);
    			}
    		break;
    		
    		case 3:
    			//dialog.showMessageDialog(null, "Menu 3");
    			
    			if (mhs.size()<1) {
    				dialog.showMessageDialog(null, "Data Mahasiswa masih kosong.");
    			} else {
	    			menu = Integer.parseInt(dialog.showInputDialog(
	    				"3.1. Hapus berdasarkan index\n"+
	    				"3.2. Hapus berdasarkan nama\n"+
	    				"3.3. Kosongkan data Mahasiswa\n"+
	    				"Pilih Menu"));
	    				
	    			switch (menu) {
	    				case 1:
					    	i = Integer.parseInt(dialog.showInputDialog("Masukkan index yang akan dihapus"));
					    	delMhs(i-1);
	    				break;
	    				
	    				case 2:
	    					/*
					    	nama = dialog.showInputDialog("Masukkan nama yang akan dihapus");
					    	delMhs(nama);
					    	*/
	    				break;
	    				
	    				case 3:
	    					mhs.clear();
	    					mhs = new ArrayList<>();
	    					dialog.showMessageDialog(null, "Data Mahasiswa telah dikosongkan");
	    				break;
	    				
	    				default: return;
	    			}
    			}    			
    		break;
    		
    		case 4:
    			//dialog.showMessageDialog(null, "Menu 4");
    			
    			if (mhs.size()<2) {
    				dialog.showMessageDialog(null, "Data Mahasiswa harus lebih dari 1");
    			} else {
	    			menu = Integer.parseInt(dialog.showInputDialog(
	    				"4.1. Urutkan 'Ascending'\n"+
	    				"4.2. Urutkan 'Descending'\n"+
	    				"Pilih Menu"));
	    			
	    			switch(menu) {
	    				case 1:
	    					sortMhs(1);
	    				break;
	    				
	    				case 2:
	    					sortMhs(2);
	    				break;
	    			}
    			}
	    	break;
    		
    		case 5:
    			//dialog.showMessageDialog(null, "Menu 5");
    			
    			printMhs();
    		break;
    		
    		case 6:
    			System.exit(0);
    		break;
    		
    		default:
    			dialog.showMessageDialog(null, "Menu yang dipilih tidak tersedia");
    		break;
    	}
    }
    
    private void addMhs() {
    	dialog = new JOptionPane();
    	nama = dialog.showInputDialog("Masukkan Nama Mahasiswa");
    	mhs.add(new Mahasiswa(nama));
    	dialog.showMessageDialog(null, "Mahasiswa bernama "+ nama + " berhasil ditambahkan");
    }
    
    private void editMhs(int index) {
    	dialog = new JOptionPane();
    	if (index < 0 || index >= mhs.size()) {
    		dialog.showMessageDialog(null, "masukkan nilai dengan benar!");
    	} else {
    		nama = dialog.showInputDialog("Masukkan nama Mahasiswa");
    		mhs.set(index, new Mahasiswa(nama));
	    	dialog.showMessageDialog(null, "Mahasiswa telah diperbarui");
    	}
    }
    
    private void delMhs(int index) {
    	if (index < 0 || index >= mhs.size()) {
    		msg = "masukkan nilai dengan benar!";
    		dialog.showMessageDialog(null, msg);
    	} else { 
    		mhs.remove(index);
    		dialog.showMessageDialog(null, "Mahasiswa pada ke-"+ (index+1) + " telah dihapus");
    	}
    }
    
    /*
    private void delMhs(String nama) {
    	for (Mahasiswa m : mhs) {
    		val = m.getNama();
    		if (!m.getNama().equals(nama)) {
	    		msg = "masukkan nilai dengan benar!";
	    		dialog.showMessageDialog(null, msg);
	    	} else {
		    	mhs.remove(m.getNama());
		    	dialog.showMessageDialog(null, "Mahasiswa dengan nama "+ nama + " telah dihapus");
	    	}
    	}
    	
    }
    */
    
    private void sortMhs(int mode) { // 1 = Ascending, 2 = Descending
    	dialog = new JOptionPane();
    	
    	switch(mode) {
    		case 1:
    			Collections.sort(mhs, new Comparator<Mahasiswa>() {
				    public int compare(Mahasiswa mhs1, Mahasiswa mhs2) {
				        return mhs1.getNama().compareTo(mhs2.getNama());
				    }
				});
				
		    	dialog.showMessageDialog(null, "Data telah diurutkan");
    		break;
    		
    		case 2:
    			Collections.sort(mhs, Collections.reverseOrder(new Comparator<Mahasiswa>(){
    				public int compare(Mahasiswa mhs1, Mahasiswa mhs2) {
				        return mhs1.getNama().compareTo(mhs2.getNama());
				    }
    			}));
		    	dialog.showMessageDialog(null, "Data telah diurutkan");
    		break;
    	}
    }
    
    private void printMhs() {
    	dialog = new JOptionPane();
    	msg = "";
    	i = 0;
    	for (Mahasiswa m : mhs) {
    		msg = msg + "Mhs ke-"+ (i+1) +": "+m.getNama()+ "\n";
    		i++;
    	}
    	dialog.showMessageDialog(null, msg);
    }
    
}